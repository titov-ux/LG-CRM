import { useState } from 'react';
import { toast } from 'sonner';
import { Mail, Pencil, Save, Send, X } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { UserAvatar } from '@/components/common/UserAvatar';
import { useAuthStore } from '@/stores/auth';
import { telegramUrl } from '@/lib/utils';
import { ROLE_LABEL } from '@/features/users/UserForm';
import { useUpdateMe } from '@/features/auth/useAuth';
import { ROLE_BADGE } from './constants';

export function ProfileHeaderCard() {
  const user = useAuthStore((s) => s.user);
  const updateMe = useUpdateMe();

  const [editing, setEditing] = useState(false);
  const [fullName, setFullName] = useState(user?.fullName ?? '');
  const [email, setEmail] = useState(user?.email ?? '');
  const [telegram, setTelegram] = useState(user?.telegram ?? '');

  if (!user) return null;

  const startEdit = () => {
    setFullName(user.fullName);
    setEmail(user.email);
    setTelegram(user.telegram ?? '');
    setEditing(true);
  };

  const cancel = () => {
    setEditing(false);
  };

  const save = async () => {
    if (fullName.trim().length < 2) {
      toast.error('Имя должно быть не короче 2 символов');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast.error('Введите корректный email');
      return;
    }
    const telegramTrimmed = telegram.trim();
    try {
      await updateMe.mutateAsync({
        fullName: fullName.trim(),
        email: email.trim(),
        telegram: telegramTrimmed || null,
      });
      setEditing(false);
      toast.success('Профиль обновлён');
    } catch {
      toast.error('Не удалось сохранить профиль');
    }
  };

  return (
    <Card>
      <CardContent className="flex flex-col gap-5 p-5 sm:flex-row sm:items-start">
        <div className="flex shrink-0 items-center gap-4">
          <UserAvatar user={user} size={72} ring interactive={false} />
          <div className="sm:hidden">
            <div className="text-base font-semibold">{user.fullName}</div>
            <div className="text-xs text-muted-foreground">{user.email}</div>
            {user.telegram ? (
              <a
                href={telegramUrl(user.telegram)}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-muted-foreground hover:text-foreground hover:underline"
              >
                {user.telegram}
              </a>
            ) : (
              <div className="text-xs text-muted-foreground/70">Telegram не указан</div>
            )}
          </div>
        </div>

        <div className="min-w-0 flex-1">
          {editing ? (
            <div className="space-y-3">
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-1">
                  <Label className="text-[12px]">ФИО</Label>
                  <Input value={fullName} onChange={(e) => setFullName(e.target.value)} />
                </div>
                <div className="space-y-1">
                  <Label className="text-[12px]">Email</Label>
                  <Input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    autoComplete="email"
                  />
                </div>
                <div className="space-y-1 sm:col-span-2">
                  <Label className="text-[12px]">Telegram</Label>
                  <Input
                    value={telegram}
                    onChange={(e) => setTelegram(e.target.value)}
                    placeholder="@username"
                    autoComplete="off"
                  />
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button variant="ghost" size="sm" onClick={cancel} className="gap-1.5">
                  <X className="h-3.5 w-3.5" />
                  Отмена
                </Button>
                <Button size="sm" onClick={save} className="gap-1.5" disabled={updateMe.isPending}>
                  <Save className="h-3.5 w-3.5" />
                  {updateMe.isPending ? 'Сохраняем...' : 'Сохранить'}
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-1">
              <div className="hidden items-center gap-2 sm:flex">
                <span className="text-lg font-semibold tracking-tight">{user.fullName}</span>
                <Badge
                  variant="secondary"
                  className={ROLE_BADGE[user.role] ?? 'bg-slate-100 text-slate-700'}
                >
                  {ROLE_LABEL[user.role]}
                </Badge>
                {!user.isActive && (
                  <Badge variant="secondary" className="bg-zinc-100 text-zinc-600">
                    Деактивирован
                  </Badge>
                )}
              </div>
              <div className="hidden text-[13px] text-muted-foreground sm:block">
                <span className="inline-flex items-center gap-1.5">
                  <Mail className="h-3.5 w-3.5" />
                  <a href={`mailto:${user.email}`} className="hover:text-foreground hover:underline">
                    {user.email}
                  </a>
                </span>
              </div>
              <div className="hidden text-[13px] text-muted-foreground sm:block">
                <span className="inline-flex items-center gap-1.5">
                  <Send className="h-3.5 w-3.5" />
                  {user.telegram ? (
                    <a
                      href={telegramUrl(user.telegram)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:text-foreground hover:underline"
                    >
                      {user.telegram}
                    </a>
                  ) : (
                    <span className="text-muted-foreground/70">Telegram не указан</span>
                  )}
                </span>
              </div>
              <div className="text-[11.5px] text-muted-foreground/80">ID: {user.id}</div>
            </div>
          )}
        </div>

        {!editing && (
          <div className="flex shrink-0 gap-2">
            <Button variant="outline" size="sm" onClick={startEdit} className="gap-1.5">
              <Pencil className="h-3.5 w-3.5" />
              Редактировать
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
